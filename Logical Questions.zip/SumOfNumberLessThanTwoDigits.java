package io.logicalProgram;

public class SumOfNumberLessThanTwoDigits {

	public static void main(String[] args) {

		int number=254676097;
		findSingleSumOfDigits(number);
		
	}

	private static void findSingleSumOfDigits(int number) {

		int sum=0;
		while(number>9) {
			sum=0;
			while(number>0) {
				int rem;
				rem=number%10;
				sum+=rem;
				number=number/10;
			}
			number=sum;
		}
		System.out.println("sum of digits is::"+sum);
	}

}
