package io.logicalProgram;

public class DecimalToIntegerUsingPredefinedMethod {

	public static void main(String[] args) {
			int dec = 3;
	      String bin = Integer.toBinaryString(dec);
	      System.out.println(bin);
	}

}
