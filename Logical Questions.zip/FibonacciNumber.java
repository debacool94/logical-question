package io.logicalProgram;

public class FibonacciNumber {

	public static void main(String[] args) {

		int i=0,j=1;
		
		System.out.print(" "+i+" "+j+" ");
		for(int k=2;k<10;k++){
			int x=i+j;
			i=j;
			j=x;
			System.out.print(" "+x);
			
			
		}
	}

}
