package io.logicalProgram;

public class SortAnArrayNegativeToPositive {

	public static void main(String[] args) {

		int[] a1 = { -1, 2, 3, 9, -4 };
		sortArray(a1);
	}

	private static void sortArray(int[] intArray) {
		int j = 0, temp;
		for (int i = 0; i < intArray.length; i++) {
			if (intArray[i] < 0) {
				if (i != j) {
					temp = intArray[i];
					intArray[i] = intArray[j];
					intArray[j] = temp;
				}
				j++;
			}

		}
		for (int i = 0; i < intArray.length; i++) {
			System.out.print(intArray[i]);
		}
	}

}
