package io.logicalProgram;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapPOC {

	public static void main(String[] args) {

	ConcurrentHashMap<Integer, String> map=new ConcurrentHashMap<Integer, String>();
	map.put(101, "a");
	map.put(102, "b");
	map.putIfAbsent(103, "c");
	map.putIfAbsent(101, "d");
	System.out.println(map);
	}

}
