package io.logicalProgram;

public class ArrayDemo {

	public static void main(String[] args) {

		int[] intArray = { 5, 7, 8, 3, 2, 4 };
		int num = 3;
		int[] result=m1(intArray, num);
		for (int i = 0; i < result.length; i++) {
			System.out.print(result[i]);
		}
		System.out.println();
	}

	private static int[] m1(int[] intArray, int num) {
		if(num>intArray.length) {
			return new int[] {-1};
		}

		int k = 0;
		for (int i = 0; i < num; i++) {
			int j = intArray[k];
			for (int x = k; x < intArray.length - 1; x++) {
				intArray[x] = intArray[x + 1];
			}
			intArray[intArray.length - 1] = j;
		}
		return intArray;		
	}

}
