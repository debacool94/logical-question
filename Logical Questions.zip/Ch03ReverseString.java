package io.javabrain.codingChallenge;

public class Ch03ReverseString {

	public static void main(String[] args) {
		String str = "Hello World!";
		System.out.println(reverseStringWithStringBuilder(str));
		System.out.println(reverseStringManually(str));
	}

	private static String reverseStringManually(String str) {
		StringBuilder sb=new StringBuilder();
		for(int i=str.length()-1;i>=0;i--) {
			sb.append(str.charAt(i));
		}
		return sb.toString();
	}

	private static String reverseStringWithStringBuilder(String str) {
		
		return new StringBuilder(str).reverse().toString();
	}

}
