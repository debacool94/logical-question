package io.javabrain.codingChallenge;

public class ArithmaticSlices {

	public static void main(String[] args) {

		int[] A= {1,3,5,7,9};
		int numberOfSlices = numberOfSlices(A);
		System.out.println("number of slices is:"+numberOfSlices);
	}

	private static int numberOfSlices(int[] a) {
		int n=a.length;
		int[] dp=new int[n];
		int result=0;
		for(int i=2;i<n;i++) {
			if(a[i]-a[i-1]==a[i-1]-a[i-2]) {
				dp[i]=dp[i-1]+1;
				result+=dp[i];
			}
		}
		return result;
	}
	

}
