package io.logicalProgram;

public class RotatingCharacterFromAString {

	public static void main(String[] args) {

		String str = "abc";
		int num = 2;
		rotatingCharacter(str, num);
	}

	private static void rotatingCharacter(String str, int num) {
		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			for (int j = 0; j < num; j++) 
					ch+=1;
			
				sb.append(ch);
			}
		System.out.println(sb.toString());
		}
		
	}
//op--def