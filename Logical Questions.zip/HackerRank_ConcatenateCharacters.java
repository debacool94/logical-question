package io.logicalProgram;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class HackerRank_ConcatenateCharacters {

	public static void main(String[] args) throws IOException {


        //BufferedReader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("enter first line:");
        String firstInput = br.readLine();  
        System.out.println("enter second line");
        String secondInput = br.readLine();  

        char[] result=secondInput.toCharArray();
        for(int i=0;i<result.length;i++) {
        	if(result[i]==' ') {
        		continue;
        	}
        	System.out.print(result[i]);
        }
		/*
		 * //Scanner Scanner s = new Scanner(System.in); String name = s.nextLine(); //
		 * Reading input from STDIN System.out.println("Hi, " + name + "."); // Writing
		 * output to STDOUT
		 */

        
	}

}
