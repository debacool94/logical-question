package io.logicalProgram;

import java.util.Scanner;

public class BinaryToDecimalUsingParseIntMethod {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a binary number ::");
		String binary = sc.next();
		int decimal = Integer.parseInt(binary, 2);
		System.out.println("Decimal value of the given binary number is ::" + decimal);

	}
}
