package io.logicalProgram;

import java.util.Arrays;

public class SmallestPositiveNumber {

	public static void main(String[] args) {
		int[] a= {1, 3, 6, 4, 1, 2};
		int[] a1= {1, 3,2};
		int[] a2= {-1,-3};
		
		SmallestPositiveNumber spn=new SmallestPositiveNumber();
		int solution = spn.solution(a2);
		System.out.println(solution);
		
	}
	 public int solution(int[] A) {
	        Arrays.sort(A);     
	        int min = 1; 
	        int cap = A.length;  
	        for (int i = 0; i < cap; i++){
	            if(A[i] == min){
	                min++;
	            }
	        }   
	        return min; 
	    }

}
