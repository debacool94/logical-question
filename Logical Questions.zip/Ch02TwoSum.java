package io.javabrain.codingChallenge;

import java.util.HashMap;
import java.util.Map;

public class Ch02TwoSum {

	public static void main(String[] args) {
		int[] numbers= new int[] {2,3,7,4,5,8};
		int target=10;
		int[] result=getTwoSum(numbers,target);
		System.out.println(result[0]+" "+result[1]);
		
	}

	private static int[] getTwoSum(int[] num, int target) {

		Map<Integer,Integer> visitedNumbers=new HashMap<Integer, Integer>();
		for(int i=0;i<num.length;i++) {
			
			int delta=target-num[i];
			if(visitedNumbers.containsKey(delta)) {
				return new int[] {visitedNumbers.get(delta),i};
			}
			visitedNumbers.put(num[i], i);
		}
		return new int[] {-1,-1};
	}

}
